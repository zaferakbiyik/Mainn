#!/bin/sh
# inpath - verify that a specified program is either valid as-is,
#   or can be found in the PATH directory list.

#!/bin/bash
while :
	do
		echo "basliyor"
		python3 ./autorclone.py
		echo "Gönderildi"
		sleep 500
		echo "beklemede"
		sleep 50
done

exit 0
